setTimeout(function() {
    alert('Успешная оплата');
    location.replace("/");
}, 3000);